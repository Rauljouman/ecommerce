import React, { useState, useEffect } from "react";
import { Box, Slider, Checkbox, FormControlLabel, Typography, Stack } from "@mui/material";

const SidebarFilters = ({ products, setFilteredProducts }) => {
  const [priceRange, setPriceRange] = useState([0, 1000]); // Rango inicial
  const [selectedCategories, setSelectedCategories] = useState([]);

  // ✅ Extraer categorías únicas de los productos
  const categories = [...new Set(products.map((product) => product.category))];

  // ✅ Aplicar filtros cada vez que cambie el rango de precios o la categoría
  useEffect(() => {
    console.log("📢 Aplicando filtros...");
    console.log("📏 Rango de precios:", priceRange);
    console.log("📂 Categorías seleccionadas:", selectedCategories);

    const filtered = products.filter((product) => {
      const withinPriceRange = product.price >= priceRange[0] && product.price <= priceRange[1];
      const matchesCategory = selectedCategories.length === 0 || selectedCategories.includes(product.category);
      return withinPriceRange && matchesCategory;
    });

    console.log("✅ Productos filtrados:", filtered);
    setFilteredProducts(filtered);
  }, [priceRange, selectedCategories, products, setFilteredProducts]);

  // ✅ Manejar el cambio en el slider de precios
  const handlePriceChange = (event, newValue) => {
    console.log("📏 Nuevo rango de precios seleccionado:", newValue);
    setPriceRange(newValue);
  };

  // ✅ Manejar cambios en las categorías seleccionadas
  const handleCategoryChange = (category) => {
    setSelectedCategories((prev) =>
      prev.includes(category) ? prev.filter((c) => c !== category) : [...prev, category]
    );
  };

  return (
    <Box
      sx={{
        width: 250,
        position: "sticky",
        top: 100,
        bgcolor: "white",
        borderRadius: 2,
        boxShadow: 3,
        p: 2,
      }}
    >
      <Typography variant="h6" sx={{ fontSize: 16, fontWeight: "bold" }}>
        Filtrar Productos
      </Typography>

      {/* Slider de Precio */}
      <Typography variant="subtitle2" sx={{ mt: 1, fontSize: 14, fontWeight: "bold" }}>
        Rango de Precios (€)
      </Typography>
      <Slider
        value={priceRange}
        onChange={handlePriceChange}
        valueLabelDisplay="auto"
        min={0}
        max={Math.max(...products.map((p) => p.price), 1000)} // Ajusta el max según los productos
        step={0.01}
        sx={{ width: "100%" }}
      />
      <Typography variant="body2">€{priceRange[0]} - €{priceRange[1]}</Typography>

      {/* Checkboxes de Categorías */}
      <Typography variant="subtitle2" sx={{ mt: 2, fontSize: 16, fontWeight: "bold" }}>
        Categorías
      </Typography>
      <Stack spacing={1} sx={{ mt: 1 }}>
        {categories.map((category) => (
          <Box key={category} sx={{ display: "flex", alignItems: "center" }}>
            <Checkbox
              checked={selectedCategories.includes(category)}
              onChange={() => handleCategoryChange(category)}
              size="small"
            />
            <Typography variant="body2">{category}</Typography>
          </Box>
        ))}
      </Stack>
    </Box>
  );
};

export default SidebarFilters;
